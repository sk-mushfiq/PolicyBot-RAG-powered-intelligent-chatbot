"""
app/services/rag_chain.py
──────────────────────────
Core RAG pipeline. Combines:
  - VectorStoreManager (retriever)
  - ConversationMemory (per-session history)
  - OpenAI LLM
  - Custom prompt templates
  - ConversationalRetrievalChain

Class:
    RAGChain — builds and runs the conversational RAG pipeline.
"""

from typing import Any

from langchain_openai import ChatOpenAI
from langchain.chains import ConversationalRetrievalChain

from app.core.config import get_settings
from app.core.logger import get_logger
from app.services.vector_store import VectorStoreManager
from app.services.chat_memory import ConversationMemory
from app.prompts.templates import (
    RAG_PROMPT,
    CONDENSE_QUESTION_PROMPT,
    NO_CONTEXT_RESPONSE,
)

logger = get_logger(__name__)
settings = get_settings()


class RAGChain:
    """
    Builds and manages a ConversationalRetrievalChain powered by
    ChromaDB retrieval and OpenAI LLM with session memory.

    Attributes:
        vector_store (VectorStoreManager): Source of retrieved context.
        memory_manager (ConversationMemory): Per-session history.
        llm (ChatOpenAI): Language model for generating answers.
    """

    def __init__(
        self,
        vector_store: VectorStoreManager,
        memory_manager: ConversationMemory,
    ) -> None:
        self.vector_store = vector_store
        self.memory_manager = memory_manager
        self.llm = self._build_llm()
        logger.info("RAGChain initialised.")

    # ──────────────────────────────────────────────
    # Public API
    # ──────────────────────────────────────────────

    def query(self, question: str, session_id: str) -> dict[str, Any]:
        """
        Process a user question through the full RAG pipeline.

        Steps:
          1. Check the vector store has documents.
          2. Get (or create) session memory.
          3. Build the ConversationalRetrievalChain.
          4. Invoke the chain with the question.
          5. Parse and return answer + source citations.

        Args:
            question: User's natural language question.
            session_id: Unique identifier for conversation continuity.

        Returns:
            Dict with keys:
                - answer (str): LLM-generated response.
                - sources (list[dict]): List of {source, page} metadata.
                - session_id (str): Echo of the session identifier.

        Raises:
            RuntimeError: If no documents have been ingested yet.
        """
        if self.vector_store.collection_is_empty():
            raise RuntimeError(
                "No documents found in the vector store. "
                "Please ingest HR documents first via POST /ingest."
            )

        memory = self.memory_manager.get_memory(session_id)
        chain = self._build_chain(memory)

        logger.info(
            f"Query received | session='{session_id}' "
            f"question='{question[:80]}'"
        )

        result = chain.invoke({"question": question})

        answer = result.get("answer", NO_CONTEXT_RESPONSE)
        sources = self._extract_sources(result.get("source_documents", []))

        logger.info(
            f"Query answered | session='{session_id}' "
            f"sources_found={len(sources)}"
        )

        return {
            "answer": answer,
            "sources": sources,
            "session_id": session_id,
        }

    # ──────────────────────────────────────────────
    # Private Helpers
    # ──────────────────────────────────────────────

    def _build_llm(self) -> ChatOpenAI:
        """Initialise the OpenAI chat model."""
        return ChatOpenAI(
            model=settings.llm_model,
            openai_api_key=settings.openai_api_key,
            temperature=0.1,          # Low temp → factual, consistent answers
            max_tokens=settings.max_tokens,
        )

    def _build_chain(
        self,
        memory: Any,
    ) -> ConversationalRetrievalChain:
        """
        Assemble the full ConversationalRetrievalChain.
        Rebuilt per call so memory is always fresh.
        """
        retriever = self.vector_store.get_retriever()

        chain = ConversationalRetrievalChain.from_llm(
            llm=self.llm,
            retriever=retriever,
            memory=memory,
            condense_question_prompt=CONDENSE_QUESTION_PROMPT,
            combine_docs_chain_kwargs={"prompt": RAG_PROMPT},
            return_source_documents=True,
            verbose=settings.debug,
        )
        return chain

    def _extract_sources(self, source_documents: list) -> list[dict]:
        """
        Deduplicate and format source citations from retrieved chunks.

        Args:
            source_documents: List of Document objects from chain output.

        Returns:
            List of unique {source, page} dicts.
        """
        seen = set()
        sources = []
        for doc in source_documents:
            meta = doc.metadata
            key = (meta.get("source", "Unknown"), meta.get("page", 0))
            if key not in seen:
                seen.add(key)
                sources.append({
                    "source": meta.get("source", "Unknown"),
                    "page": meta.get("page", 0),
                })
        return sources
