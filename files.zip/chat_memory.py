"""
app/services/chat_memory.py
────────────────────────────
Per-session conversation memory manager.
Stores chat history so the RAG chain resolves follow-up questions correctly.

Class:
    ConversationMemory — manages LangChain ConversationBufferMemory per session.
"""

from typing import Dict
from langchain.memory import ConversationBufferMemory
from app.core.logger import get_logger

logger = get_logger(__name__)


class ConversationMemory:
    """
    Manages one ConversationBufferMemory object per session_id.
    Sessions are stored in-process (suitable for single-instance deployment).

    Attributes:
        _sessions (dict): Map of session_id → ConversationBufferMemory.
    """

    def __init__(self) -> None:
        self._sessions: Dict[str, ConversationBufferMemory] = {}
        logger.info("ConversationMemory initialised.")

    def get_memory(self, session_id: str) -> ConversationBufferMemory:
        """
        Return existing memory for session_id, or create a new one.

        Args:
            session_id: Unique identifier for a user session.

        Returns:
            ConversationBufferMemory instance.
        """
        if session_id not in self._sessions:
            self._sessions[session_id] = ConversationBufferMemory(
                memory_key="chat_history",
                return_messages=True,
                output_key="answer",
            )
            logger.info(f"New memory session created: {session_id}")
        return self._sessions[session_id]

    def clear_session(self, session_id: str) -> None:
        """
        Clear history for a specific session.

        Args:
            session_id: Session to clear.
        """
        if session_id in self._sessions:
            self._sessions[session_id].clear()
            logger.info(f"Memory cleared for session: {session_id}")

    def clear_all(self) -> None:
        """Clear all session memories."""
        self._sessions.clear()
        logger.warning("All conversation memories cleared.")

    def session_exists(self, session_id: str) -> bool:
        """Return True if a session already exists."""
        return session_id in self._sessions

    def get_history(self, session_id: str) -> list:
        """
        Return raw message history for a session.

        Args:
            session_id: Session identifier.

        Returns:
            List of BaseMessage objects, empty list if session not found.
        """
        if session_id not in self._sessions:
            return []
        memory = self._sessions[session_id]
        return memory.chat_memory.messages
